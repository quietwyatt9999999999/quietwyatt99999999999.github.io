function f(g = top, l = location) {
  check(g);
  check(l);
}

f();
