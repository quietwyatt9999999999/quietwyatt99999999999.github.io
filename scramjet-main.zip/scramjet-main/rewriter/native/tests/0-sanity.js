check(top);
check(location);
check(window.location);
check(top["loca" + "tion"]);
check(self["loca" + "tion"])
