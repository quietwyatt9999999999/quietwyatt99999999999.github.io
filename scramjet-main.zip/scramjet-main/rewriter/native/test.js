window.location.href = "http://example.com";

console.log(top.window.aaa);
consle.log(globalThis["win" + "dow"]);

globalThis.eval("..");

let ref = { b: this.top.window, c: globalThis["win" + "dow"] };


export default ref;

export { ref };


export { ref as default };

export { S } from "module";
export * from "module";
import sd from "d"

location += "http://example.com";

function f() { return import("x") }


let window = (1, window);

let x = new this.Abc();

try{}catch(e){this.a.log()};

await import("test")


import{c as d,u as g,a as l,r as i,b,d as m,g as p,e as h,f as v,h as k}from"./1e3cB0WW.js";
