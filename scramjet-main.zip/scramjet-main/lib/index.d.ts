/**
 * @fileoverview
 * Scramjet path export for routing functionality
 */

declare const scramjetPath: string;

export { scramjetPath };
